package com.example.tresenrayaandroid;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button[][] buttons = new Button[3][3];
    private boolean playerXTurn = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeButtons();
        Button checkResultButton = findViewById(R.id.checkResultButton);
        checkResultButton.setOnClickListener(view -> checkWinner());
    }

    private void initializeButtons() {
        buttons[0][0] = findViewById(R.id.btn1);
        buttons[0][1] = findViewById(R.id.btn2);
        buttons[0][2] = findViewById(R.id.btn3);
        buttons[1][0] = findViewById(R.id.btn4);
        buttons[1][1] = findViewById(R.id.btn5);
        buttons[1][2] = findViewById(R.id.btn6);
        buttons[2][0] = findViewById(R.id.btn7);
        buttons[2][1] = findViewById(R.id.btn8);
        buttons[2][2] = findViewById(R.id.btn9);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setOnClickListener(new CellClickListener(i, j));
            }
        }
    }

    private class CellClickListener implements View.OnClickListener {
        int row, col;

        CellClickListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void onClick(View view) {
            Button button = (Button) view;
            if (!button.getText().toString().equals("")) return;

            if (playerXTurn) {
                button.setText("X");
            } else {
                button.setText("O");
            }
            playerXTurn = !playerXTurn;
        }
    }

    private void checkWinner() {
        // Comprobación de filas, columnas y diagonales
        for (int i = 0; i < 3; i++) {
            if (checkEqual(buttons[i][0], buttons[i][1], buttons[i][2]) ||
                    checkEqual(buttons[0][i], buttons[1][i], buttons[2][i])) {
                showWinner(buttons[i][i].getText().toString());
                return;
            }
        }

        if (checkEqual(buttons[0][0], buttons[1][1], buttons[2][2]) ||
                checkEqual(buttons[0][2], buttons[1][1], buttons[2][0])) {
            showWinner(buttons[1][1].getText().toString());
        }
    }

    private boolean checkEqual(Button b1, Button b2, Button b3) {
        return !b1.getText().toString().equals("") &&
                b1.getText().toString().equals(b2.getText().toString()) &&
                b1.getText().toString().equals(b3.getText().toString());
    }

    private void showWinner(String winner) {
        Toast.makeText(this, "Ganador: " + winner, Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }
        playerXTurn = true;
    }
}
